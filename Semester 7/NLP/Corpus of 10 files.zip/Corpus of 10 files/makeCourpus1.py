import os
from collections import Counter
import string
import re

# Function to read all .txt files from a directory
def read_corpus(directory):
    corpus = ''
    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            file_path = os.path.join(directory, filename)
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    corpus += file.read() + ' '  # Add a space between file contents
            except Exception as e:
                print(f"Error reading {file_path}: {e}")
    return corpus

# Function to preprocess text (tokenize, lowercase, remove punctuation)
def preprocess_text(text):
    text = text.lower()  # Convert to lowercase
    text = re.sub(f"[{string.punctuation}]", " ", text)  # Remove punctuation
    tokens = text.split()  # Split the text into words (tokens)
    return tokens

# Function to calculate tokens and types
def calculate_tokens_and_types(corpus):
    tokens = preprocess_text(corpus)  # Preprocess the text
    types = set(tokens)  # Get unique words (types)
    return tokens, types

# Function to calculate frequency of each type
def calculate_frequency(tokens):
    return Counter(tokens)

# Directory containing the .txt files
corpus_directory = './corpus_eng'

# Step 1: Read the corpus
corpus = read_corpus(corpus_directory)

# Step 2: Calculate tokens and types
tokens, types = calculate_tokens_and_types(corpus)

# Step 3: Calculate frequency of each type
frequency = calculate_frequency(tokens)

# Output results
print(f"Number of tokens: {len(tokens)}")
print(f"Number of types: {len(types)}")
print("Frequency of each type:")
for word, freq in frequency.items():
    print(f"{word}: {freq}")
