﻿using System;
using System.Collections.Generic;

namespace SEClassWeb.Models;

public partial class Product
{
    public int Id { get; set; }

    public string? Pname { get; set; }

    public int? Price { get; set; }
}
